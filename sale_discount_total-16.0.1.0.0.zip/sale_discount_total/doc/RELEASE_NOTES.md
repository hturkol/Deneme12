## Module <sale_discount_total>

#### 10.09.2021
#### Version 16.0.1.0.0
#### ADD
Initial commit for Sale Discount On Total Amount



